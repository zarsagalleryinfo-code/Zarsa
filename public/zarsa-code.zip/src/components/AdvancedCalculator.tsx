import React, { useState, useEffect } from 'react';
import { 
  Calculator, 
  Sparkles, 
  TrendingUp, 
  Scale, 
  Percent, 
  Coins, 
  Copy, 
  Check, 
  ArrowRight, 
  RefreshCw, 
  Sliders, 
  HelpCircle, 
  Info, 
  Wallet,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { StoreSettings } from '../types';
import { applyRounding, getRoundingDescription } from '../utils/rounding';

interface AdvancedCalculatorProps {
  goldPrice: number;
  setGoldPrice: (price: number) => void;
  store: StoreSettings;
  taxEnabledGlobal: boolean;
  showNotification: (message: string, type?: 'success' | 'amber' | 'error') => void;
  onOpenRegularCalculator?: () => void;
}

type AdvancedTab = 'budget' | 'find-rate' | 'find-weight' | 'find-fee';

export const AdvancedCalculator: React.FC<AdvancedCalculatorProps> = ({
  goldPrice,
  setGoldPrice,
  store,
  taxEnabledGlobal,
  showNotification,
  onOpenRegularCalculator
}) => {
  const [activeSubTab, setActiveSubTab] = useState<AdvancedTab>('budget');
  const [copied, setCopied] = useState<boolean>(false);

  // Helper number parser & formatter
  const parseNumber = (val: string): number => {
    const cleaned = val.replace(/[^0-9]/g, '');
    return cleaned ? parseInt(cleaned, 10) : 0;
  };

  const parseFloatNumber = (val: string): number => {
    // Convert Persian numbers to English
    const en = val.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d).toString()).replace(/,/g, '');
    const num = parseFloat(en);
    return isNaN(num) ? 0 : num;
  };

  const formatToman = (val: number): string => {
    return (val || 0).toLocaleString('fa-IR');
  };

  // =========================================================================
  // 1. FEATURE 1: BUDGET / "با این بودجه چی می‌تونم بخرم؟"
  // =========================================================================
  const [bBudget, setBBudget] = useState<number>(500000000); // 500 million Toman
  const [bGoldRate, setBGoldRate] = useState<number>(goldPrice || 3500000);
  const [bFeePercent, setBFeePercent] = useState<number>(12); // Average fee %
  const [bProfitPercent, setBProfitPercent] = useState<number>(7); // Standard 7% profit
  const [bTaxActive, setBTaxActive] = useState<boolean>(taxEnabledGlobal);

  // Synchronize gold rate with master goldPrice if changed
  useEffect(() => {
    if (goldPrice > 0 && Math.abs(bGoldRate - goldPrice) > 100000) {
      setBGoldRate(goldPrice);
    }
  }, [goldPrice]);

  // Compute budget output
  const computeBudgetResult = () => {
    const rate = bGoldRate || 1;
    const feePct = (bFeePercent || 0) / 100;
    const profitPct = (bProfitPercent || 0) / 100;
    const taxRate = bTaxActive ? 0.09 : 0;

    // For 1 gram:
    // Raw = rate
    // Fee = rate * feePct
    // Profit = (rate + Fee) * profitPct = rate * (1 + feePct) * profitPct
    // Tax = (Fee + Profit) * taxRate
    // CostPerGram = Raw + Fee + Profit + Tax
    const rawPerGram = rate;
    const feePerGram = rate * feePct;
    const profitPerGram = (rawPerGram + feePerGram) * profitPct;
    const taxPerGram = (feePerGram + profitPerGram) * taxRate;
    const totalCostPerGram = rawPerGram + feePerGram + profitPerGram + taxPerGram;

    if (totalCostPerGram <= 0) return { weight: 0, rawTotal: 0, feeTotal: 0, profitTotal: 0, taxTotal: 0 };

    const targetWeight = Number((bBudget / totalCostPerGram).toFixed(3));
    const rawTotal = Math.round(targetWeight * rawPerGram);
    const feeTotal = Math.round(targetWeight * feePerGram);
    const profitTotal = Math.round(targetWeight * profitPerGram);
    const taxTotal = Math.round(targetWeight * taxPerGram);

    return {
      weight: targetWeight,
      rawTotal,
      feeTotal,
      profitTotal,
      taxTotal,
      costPerGram: Math.round(totalCostPerGram)
    };
  };

  const budgetResult = computeBudgetResult();

  // =========================================================================
  // 2. FEATURE 2: FIND GOLD RATE / معکوس نرخ
  // =========================================================================
  const [rTotalAmount, setRTotalAmount] = useState<number>(18500000);
  const [rWeight, setRWeight] = useState<number>(3.5);
  const [rFeePercent, setRFeePercent] = useState<number>(14);
  const [rProfitPercent, setRProfitPercent] = useState<number>(7);
  const [rTaxActive, setRTaxActive] = useState<boolean>(taxEnabledGlobal);

  const computeFindRateResult = () => {
    const total = rTotalAmount || 0;
    const weight = rWeight || 0;
    if (total <= 0 || weight <= 0) return { rate: 0, mazaneh: 0, diffWithLive: 0 };

    const feePct = (rFeePercent || 0) / 100;
    const profitPct = (rProfitPercent || 0) / 100;
    const taxRate = rTaxActive ? 0.09 : 0;

    // Total = Weight * Rate * Multiplier
    // Multiplier = 1 + feePct + (1 + feePct) * profitPct + [feePct + (1 + feePct) * profitPct] * taxRate
    const feeTerm = feePct;
    const profitTerm = (1 + feePct) * profitPct;
    const taxTerm = (feeTerm + profitTerm) * taxRate;
    const multiplier = 1 + feeTerm + profitTerm + taxTerm;

    const rate = Math.round(total / (weight * multiplier));
    const mazaneh = Math.round(rate * 4.3318);
    const diffWithLive = rate - (goldPrice || 0);

    return { rate, mazaneh, diffWithLive, multiplier };
  };

  const findRateResult = computeFindRateResult();

  // =========================================================================
  // 3. FEATURE 3: FIND WEIGHT / معکوس وزن
  // =========================================================================
  const [wTotalAmount, setWTotalAmount] = useState<number>(25000000);
  const [wGoldRate, setWGoldRate] = useState<number>(goldPrice || 3500000);
  const [wFeePercent, setWFeePercent] = useState<number>(10);
  const [wProfitPercent, setWProfitPercent] = useState<number>(7);
  const [wTaxActive, setWTaxActive] = useState<boolean>(taxEnabledGlobal);

  const computeFindWeightResult = () => {
    const total = wTotalAmount || 0;
    const rate = wGoldRate || 1;
    if (total <= 0 || rate <= 0) return { weight: 0, soot: 0, mesghal: 0, rawGold: 0, fee: 0, profit: 0, tax: 0 };

    const feePct = (wFeePercent || 0) / 100;
    const profitPct = (wProfitPercent || 0) / 100;
    const taxRate = wTaxActive ? 0.09 : 0;

    const feeTerm = feePct;
    const profitTerm = (1 + feePct) * profitPct;
    const taxTerm = (feeTerm + profitTerm) * taxRate;
    const multiplier = 1 + feeTerm + profitTerm + taxTerm;
    const costPerGram = rate * multiplier;

    const weight = Number((total / costPerGram).toFixed(3));
    const soot = Math.round(weight * 1000);
    const mesghal = Number((weight / 4.6083).toFixed(3));

    const rawGold = Math.round(weight * rate);
    const fee = Math.round(rawGold * feePct);
    const profit = Math.round((rawGold + fee) * profitPct);
    const tax = Math.round((fee + profit) * taxRate);

    return {
      weight,
      soot,
      mesghal,
      costPerGram: Math.round(costPerGram),
      rawGold,
      fee,
      profit,
      tax
    };
  };

  const findWeightResult = computeFindWeightResult();

  // =========================================================================
  // 4. FEATURE 4: FIND FEE & PROFIT / پیدا کردن سود و اجرت
  // =========================================================================
  const [fTotalAmount, setFTotalAmount] = useState<number>(31500000);
  const [fWeight, setFWeight] = useState<number>(6.5);
  const [fGoldRate, setFGoldRate] = useState<number>(goldPrice || 3500000);
  const [fTaxActive, setFTaxActive] = useState<boolean>(taxEnabledGlobal);

  const computeFindFeeResult = () => {
    const total = fTotalAmount || 0;
    const weight = fWeight || 0;
    const rate = fGoldRate || 0;
    const rawGold = Math.round(weight * rate);

    if (total <= 0 || weight <= 0 || rate <= 0) {
      return { rawGold: 0, diff: 0, totalMarkup: 0, feeAmount: 0, feePercent: 0, profitAmount: 0, profitPercent: 7, taxAmount: 0, totalMarkupPercent: 0 };
    }

    const diff = total - rawGold;
    const taxRate = fTaxActive ? 0.09 : 0;

    // diff = (Fee + Profit) * (1 + taxRate)
    const totalMarkup = Math.round(diff / (1 + taxRate));
    const taxAmount = diff - totalMarkup;

    // Standard union profit: 7% on (raw + fee)
    // totalMarkup = Fee + (raw + Fee) * 0.07 = Fee * 1.07 + raw * 0.07
    // Fee * 1.07 = totalMarkup - raw * 0.07
    const profitStatutoryRate = 0.07;
    const feeExact = (totalMarkup - rawGold * profitStatutoryRate) / (1 + profitStatutoryRate);

    let feeAmount = Math.max(0, Math.round(feeExact));
    let profitAmount = Math.max(0, totalMarkup - feeAmount);
    let feePercent = rawGold > 0 ? Number(((feeAmount / rawGold) * 100).toFixed(2)) : 0;
    let totalMarkupPercent = rawGold > 0 ? Number(((totalMarkup / rawGold) * 100).toFixed(2)) : 0;

    return {
      rawGold,
      diff,
      totalMarkup,
      feeAmount,
      feePercent,
      profitAmount,
      profitPercent: 7,
      taxAmount: Math.max(0, taxAmount),
      totalMarkupPercent
    };
  };

  const findFeeResult = computeFindFeeResult();

  // Handle Copy to clipboard
  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    showNotification('نتیجه محاسبه با موفقیت کپی شد', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & Title */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 p-4 rounded-2xl border border-zinc-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-44 h-44 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/40 flex items-center justify-center text-[#ffd700] shadow-md shadow-[#d4af37]/10">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                <span>ماشین‌حساب پیشرفته زرسا</span>
                <span className="text-[10px] bg-[#d4af37] text-black font-black px-2 py-0.5 rounded-full">ویژه طلافروشان</span>
              </h2>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                محاسبه بودجه مشتری، پیدا کردن نرخ، استخراج وزن و کشف سود و اجرت فاکتور
              </p>
            </div>
          </div>

          {/* Gold rate badge */}
          <div className="flex items-center gap-2 bg-zinc-950/80 px-3 py-1.5 rounded-xl border border-zinc-800 text-xs">
            <span className="text-zinc-500 text-[10px]">نرخ روز طلا:</span>
            <span className="font-mono font-black text-[#ffd700]">{goldPrice.toLocaleString('fa-IR')}</span>
            <span className="text-[10px] text-zinc-500">تومان</span>
          </div>
        </div>
      </div>

      {/* SUB-TABS SELECTOR (4 MAIN CAPABILITIES) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-zinc-950 p-1.5 rounded-2xl border border-zinc-800">
        <button
          onClick={() => setActiveSubTab('budget')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'budget'
              ? 'bg-[#d4af37] text-black font-black shadow-lg shadow-[#d4af37]/20'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
          }`}
        >
          <Wallet className="w-4 h-4 shrink-0" />
          <span>بودجه مشتری</span>
        </button>

        <button
          onClick={() => setActiveSubTab('find-rate')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'find-rate'
              ? 'bg-[#d4af37] text-black font-black shadow-lg shadow-[#d4af37]/20'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
          }`}
        >
          <TrendingUp className="w-4 h-4 shrink-0" />
          <span>پیدا کردن نرخ</span>
        </button>

        <button
          onClick={() => setActiveSubTab('find-weight')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'find-weight'
              ? 'bg-[#d4af37] text-black font-black shadow-lg shadow-[#d4af37]/20'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
          }`}
        >
          <Scale className="w-4 h-4 shrink-0" />
          <span>پیدا کردن وزن</span>
        </button>

        <button
          onClick={() => setActiveSubTab('find-fee')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'find-fee'
              ? 'bg-[#d4af37] text-black font-black shadow-lg shadow-[#d4af37]/20'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
          }`}
        >
          <Percent className="w-4 h-4 shrink-0" />
          <span>پیدا کردن اجرت و سود</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. TAB: BUDGET RECOMMENDER ("با این بودجه چی می‌تونم بخرم؟") */}
      {/* ========================================================================= */}
      {activeSubTab === 'budget' && (
        <div className="space-y-4">
          <div className="bg-zinc-900/80 p-4 sm:p-5 rounded-3xl border border-zinc-800 space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-[#ffd700]" />
                <h3 className="text-sm font-black text-white">مشخصات بودجه خرید مشتری</h3>
              </div>
              <span className="text-[11px] text-zinc-400">پیشنهاد وزن مناسب در ویترین</span>
            </div>

            {/* Budget Input with quick presets */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <label className="font-bold text-zinc-300">مبلغ کل بودجه مشتری (تومان)</label>
                <span className="font-mono text-xs text-[#ffd700] font-bold">
                  {formatToman(bBudget)} تومان
                </span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(bBudget)}
                  onChange={(e) => setBBudget(parseNumber(e.target.value))}
                  placeholder="مثال: ۵۰۰,۰۰۰,۰۰۰"
                  className="w-full h-13 px-4 bg-zinc-950 border border-zinc-700/80 rounded-2xl text-xl sm:text-2xl font-black text-[#ffd700] font-mono focus:border-[#d4af37] outline-none"
                />
                <span className="absolute left-4 top-3.5 text-xs text-zinc-400">تومان</span>
              </div>

              {/* Quick Budget Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 text-[11px]">
                <span className="text-zinc-500 shrink-0">بودجه سریع:</span>
                {[20000000, 50000000, 100000000, 200000000, 500000000, 1000000000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setBBudget(amt)}
                    className={`px-2.5 py-1 rounded-lg shrink-0 font-bold transition-all cursor-pointer ${
                      bBudget === amt
                        ? 'bg-[#d4af37] text-black font-black'
                        : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                    }`}
                  >
                    {amt >= 1000000000
                      ? `${(amt / 1000000000).toLocaleString('fa-IR')} میلیارد`
                      : `${(amt / 1000000).toLocaleString('fa-IR')} میلیون`}
                  </button>
                ))}
              </div>
            </div>

            {/* Inputs Grid: Gold Rate, Wage %, Profit %, Tax */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              
              {/* Gold Rate */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-400">نرخ طلای ۱۸ عیار (تومان)</span>
                  <button
                    type="button"
                    onClick={() => setBGoldRate(goldPrice)}
                    className="text-[10px] text-[#d4af37] hover:underline"
                  >
                    بروزرسانی به تابلو
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={formatToman(bGoldRate)}
                    onChange={(e) => setBGoldRate(parseNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">تومان</span>
                </div>
              </div>

              {/* Wage / Fee % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-400">میانگین اجرت ساخت</span>
                  <span className="font-mono text-[#ffd700] font-bold">{bFeePercent}٪</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    step="0.5"
                    value={bFeePercent || ''}
                    onChange={(e) => setBFeePercent(parseFloatNumber(e.target.value))}
                    className="w-20 h-11 px-2 text-center bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <div className="flex-1 flex gap-1 overflow-x-auto">
                    {[10, 12, 15, 18, 20].map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setBFeePercent(f)}
                        className={`flex-1 py-2 px-1 text-[11px] rounded-lg font-bold transition-all cursor-pointer ${
                          bFeePercent === f
                            ? 'bg-[#d4af37] text-black font-black'
                            : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                        }`}
                      >
                        {f}٪
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Profit % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-400">سود طلافروشی (پیش‌فرض ۷٪)</span>
                  <span className="font-mono text-zinc-300 font-bold">{bProfitPercent}٪</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.5"
                    value={bProfitPercent || ''}
                    onChange={(e) => setBProfitPercent(parseFloatNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setBProfitPercent(7)}
                    className="px-3 h-11 bg-zinc-800 text-zinc-300 text-xs rounded-xl font-bold shrink-0 hover:bg-zinc-700"
                  >
                    ۷٪ قانونی
                  </button>
                </div>
              </div>

              {/* VAT Tax Toggle */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">مالیات ارزش‌افزوده</span>
                  <span className="text-[10px] text-zinc-400">۹٪ بر روی اجرت و سود</span>
                </div>
                <button
                  type="button"
                  onClick={() => setBTaxActive(!bTaxActive)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    bTaxActive
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {bTaxActive ? 'فعال (۹٪)' : 'معاف / خاموش'}
                </button>
              </div>

            </div>

          </div>

          {/* RESULT CARD FOR BUDGET */}
          <div className="bg-gradient-to-br from-zinc-900 via-zinc-950 to-black p-5 rounded-3xl border-2 border-[#d4af37]/60 shadow-2xl relative overflow-hidden space-y-4">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/15 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#ffd700]" />
                <span>نتیجه محاسبات هوشمند بودجه</span>
              </span>
              <span className="text-[11px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-full font-mono">
                نرخ تمام‌شده هر گرم: {formatToman(budgetResult.costPerGram)} ت
              </span>
            </div>

            {/* HERO WEIGHT CALLOUT (AS REQUESTED BY USER) */}
            <div className="bg-[#d4af37]/10 p-4 rounded-2xl border border-[#d4af37]/30 text-center space-y-1.5">
              <span className="text-xs font-bold text-amber-200">وزن طلای قابل خرید با این بودجه:</span>
              <div className="text-3xl sm:text-4xl font-black text-[#ffd700] font-mono tracking-tight">
                {budgetResult.weight.toLocaleString('fa-IR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })}{' '}
                <span className="text-lg font-bold text-white">گرم</span>
              </div>
              <div className="text-xs text-zinc-300 pt-1 border-t border-[#d4af37]/20 flex items-center justify-center gap-1 leading-relaxed">
                <span>💡</span>
                <strong className="text-amber-100">
                  داخل مغازه دنبال اجناسی با وزن حدود {budgetResult.weight.toLocaleString('fa-IR', { maximumFractionDigits: 2 })} گرم (بازه {(budgetResult.weight * 0.95).toFixed(2).replace('.', '/')} تا {(budgetResult.weight * 1.05).toFixed(2).replace('.', '/')} گرم) باشید.
                </strong>
              </div>
            </div>

            {/* Financial Item Breakdown Table */}
            <div className="space-y-2 text-xs pt-1">
              <div className="flex justify-between py-1.5 border-b border-zinc-800 text-zinc-300">
                <span>ارزش طلای خام ({budgetResult.weight} گرم):</span>
                <span className="font-mono font-bold text-white">{formatToman(budgetResult.rawTotal)} تومان</span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-zinc-800 text-zinc-300">
                <span>مبلغ اجرت ساخت ({bFeePercent}٪):</span>
                <span className="font-mono font-bold text-amber-300">{formatToman(budgetResult.feeTotal)} تومان</span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-zinc-800 text-zinc-300">
                <span>سود فروشگاه ({bProfitPercent}٪):</span>
                <span className="font-mono font-bold text-zinc-200">{formatToman(budgetResult.profitTotal)} تومان</span>
              </div>

              {bTaxActive && (
                <div className="flex justify-between py-1.5 border-b border-zinc-800 text-zinc-300">
                  <span>مالیات ارزش‌افزوده (۹٪ اجرت و سود):</span>
                  <span className="font-mono font-bold text-zinc-300">{formatToman(budgetResult.taxTotal)} تومان</span>
                </div>
              )}

              <div className="flex justify-between py-2 text-sm font-black text-[#ffd700] pt-2">
                <span>جمع کل پرداختی (معادل بودجه):</span>
                <span className="font-mono">{formatToman(bBudget)} تومان</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  const summaryText = `گالری طلا ${store.name}\n` +
                    `پیشنهاد خرید بر اساس بودجه:\n` +
                    `💰 بودجه: ${formatToman(bBudget)} تومان\n` +
                    `⚖️ وزن پیشنهادی طلا: ${budgetResult.weight} گرم\n` +
                    `📊 میانگین اجرت: ${bFeePercent}٪ | سود: ${bProfitPercent}٪\n` +
                    `💡 راهنمایی: انتخاب اجناس با وزن حدود ${budgetResult.weight} گرم در مغازه`;
                  handleCopyText(summaryText);
                }}
                className="flex-1 h-11 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-[#d4af37]" />}
                <span>کپی خلاصه پیشنهاد</span>
              </button>

              {onOpenRegularCalculator && (
                <button
                  type="button"
                  onClick={onOpenRegularCalculator}
                  className="px-4 h-11 rounded-xl bg-[#d4af37] hover:bg-[#b89320] text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>انتقال به فاکتور فروش</span>
                </button>
              )}
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TAB: FIND GOLD RATE (معکوس نرخ) */}
      {/* ========================================================================= */}
      {activeSubTab === 'find-rate' && (
        <div className="space-y-4">
          <div className="bg-zinc-900/80 p-4 sm:p-5 rounded-3xl border border-zinc-800 space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#ffd700]" />
                <h3 className="text-sm font-black text-white">پیدا کردن نرخ طلا (محاسبه معکوس)</h3>
              </div>
              <span className="text-[11px] text-zinc-400">کشف نرخ پایه فاکتور</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              {/* Total Final Price */}
              <div className="sm:col-span-2 bg-zinc-950 p-3.5 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">مبلغ نهایی فاکتور (تومان)</label>
                  <span className="font-mono text-[#ffd700] font-bold">{formatToman(rTotalAmount)} تومان</span>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(rTotalAmount)}
                  onChange={(e) => setRTotalAmount(parseNumber(e.target.value))}
                  placeholder="مبلغ نهایی..."
                  className="w-full h-12 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-lg font-black text-[#ffd700] font-mono focus:border-[#d4af37] outline-none"
                />
              </div>

              {/* Weight */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">وزن دقیق طلا (گرم)</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.001"
                    value={rWeight || ''}
                    onChange={(e) => setRWeight(parseFloatNumber(e.target.value))}
                    placeholder="مثال: ۳.۵"
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">گرم</span>
                </div>
              </div>

              {/* Wage % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">درصد اجرت ساخت</label>
                  <span className="font-mono text-zinc-400">{rFeePercent}٪</span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={rFeePercent || ''}
                    onChange={(e) => setRFeePercent(parseFloatNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">درصد</span>
                </div>
              </div>

              {/* Profit % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">درصد سود طلافروش</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={rProfitPercent || ''}
                    onChange={(e) => setRProfitPercent(parseFloatNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">درصد</span>
                </div>
              </div>

              {/* Tax Switch */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">مالیات بر ارزش‌افزوده</span>
                  <span className="text-[10px] text-zinc-400">آیا در فاکتور لحاظ شده؟</span>
                </div>
                <button
                  type="button"
                  onClick={() => setRTaxActive(!rTaxActive)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    rTaxActive
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {rTaxActive ? 'محاسبه شده (۹٪)' : 'بدون مالیات'}
                </button>
              </div>

            </div>

          </div>

          {/* RESULT CARD FOR FIND RATE */}
          <div className="bg-gradient-to-br from-zinc-900 via-zinc-950 to-black p-5 rounded-3xl border-2 border-[#d4af37]/60 shadow-2xl relative overflow-hidden space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#ffd700]" />
                <span>نرخ محاسبه‌شده طلای این فاکتور</span>
              </span>
              <span className="text-[11px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-full font-mono">
                عیار ۷۵۰ (۱۸ عیار)
              </span>
            </div>

            <div className="bg-[#d4af37]/10 p-4 rounded-2xl border border-[#d4af37]/30 text-center space-y-1">
              <span className="text-xs font-bold text-amber-200">نرخ هر گرم طلای ۱۸ عیار:</span>
              <div className="text-3xl sm:text-4xl font-black text-[#ffd700] font-mono tracking-tight">
                {formatToman(findRateResult.rate)}{' '}
                <span className="text-base font-bold text-white">تومان</span>
              </div>
              <div className="text-xs text-zinc-300 pt-1 font-mono">
                معادل مظنه مثقال طلا: {formatToman(findRateResult.mazaneh)} تومان
              </div>
            </div>

            {/* Comparison with today's store live rate */}
            <div className="flex items-center justify-between bg-zinc-950 p-3 rounded-2xl border border-zinc-800 text-xs">
              <span className="text-zinc-400">مقایسه با تابلوی روز مغازه:</span>
              <span className={`font-mono font-bold ${
                findRateResult.diffWithLive > 0 
                  ? 'text-emerald-400' 
                  : findRateResult.diffWithLive < 0 
                  ? 'text-amber-400' 
                  : 'text-zinc-300'
              }`}>
                {findRateResult.diffWithLive > 0 ? '+' : ''}
                {formatToman(findRateResult.diffWithLive)} تومان{' '}
                {findRateResult.diffWithLive > 0 ? '(بالاتر از تابلو)' : findRateResult.diffWithLive < 0 ? '(پایین‌تر از تابلو)' : '(دقیقاً برابر تابلو)'}
              </span>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  if (findRateResult.rate > 0) {
                    setGoldPrice(findRateResult.rate);
                    showNotification(`نرخ تابلوی برنامه به ${formatToman(findRateResult.rate)} تومان تغییر یافت`, 'success');
                  }
                }}
                className="flex-1 h-11 rounded-xl bg-[#d4af37] hover:bg-[#b89320] text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>تنظیم این نرخ به عنوان تابلوی روز مغازه</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. TAB: FIND WEIGHT (معکوس وزن) */}
      {/* ========================================================================= */}
      {activeSubTab === 'find-weight' && (
        <div className="space-y-4">
          <div className="bg-zinc-900/80 p-4 sm:p-5 rounded-3xl border border-zinc-800 space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <Scale className="w-4 h-4 text-[#ffd700]" />
                <h3 className="text-sm font-black text-white">پیدا کردن وزن طلا (محاسبه معکوس وزن)</h3>
              </div>
              <span className="text-[11px] text-zinc-400">استخراج دقیق وزن به گرم و سوت</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              {/* Total Final Price */}
              <div className="sm:col-span-2 bg-zinc-950 p-3.5 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">مبلغ نهایی پرداختی (تومان)</label>
                  <span className="font-mono text-[#ffd700] font-bold">{formatToman(wTotalAmount)} تومان</span>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(wTotalAmount)}
                  onChange={(e) => setWTotalAmount(parseNumber(e.target.value))}
                  placeholder="مبلغ نهایی..."
                  className="w-full h-12 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-lg font-black text-[#ffd700] font-mono focus:border-[#d4af37] outline-none"
                />
              </div>

              {/* Gold Rate */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">نرخ هر گرم طلای ۱۸ عیار</label>
                  <button
                    type="button"
                    onClick={() => setWGoldRate(goldPrice)}
                    className="text-[10px] text-[#d4af37]"
                  >
                    تابلو
                  </button>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(wGoldRate)}
                  onChange={(e) => setWGoldRate(parseNumber(e.target.value))}
                  className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                />
              </div>

              {/* Wage % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">درصد اجرت ساخت</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={wFeePercent || ''}
                    onChange={(e) => setWFeePercent(parseFloatNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">درصد</span>
                </div>
              </div>

              {/* Profit % */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">درصد سود طلافروش</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={wProfitPercent || ''}
                    onChange={(e) => setWProfitPercent(parseFloatNumber(e.target.value))}
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">درصد</span>
                </div>
              </div>

              {/* Tax Toggle */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">مالیات ارزش‌افزوده</span>
                  <span className="text-[10px] text-zinc-400">۹٪ اجرت و سود</span>
                </div>
                <button
                  type="button"
                  onClick={() => setWTaxActive(!wTaxActive)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    wTaxActive
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {wTaxActive ? 'فعال (۹٪)' : 'معاف'}
                </button>
              </div>

            </div>

          </div>

          {/* RESULT CARD FOR FIND WEIGHT */}
          <div className="bg-gradient-to-br from-zinc-900 via-zinc-950 to-black p-5 rounded-3xl border-2 border-[#d4af37]/60 shadow-2xl relative overflow-hidden space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#ffd700]" />
                <span>وزن محاسبه‌شده برای این طلا</span>
              </span>
              <span className="text-[11px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-full font-mono">
                دقت ۳ رقم اعشار (طلافروشی)
              </span>
            </div>

            <div className="bg-[#d4af37]/10 p-4 rounded-2xl border border-[#d4af37]/30 text-center space-y-1">
              <span className="text-xs font-bold text-amber-200">وزن دقیق طلا:</span>
              <div className="text-3xl sm:text-4xl font-black text-[#ffd700] font-mono tracking-tight">
                {findWeightResult.weight.toLocaleString('fa-IR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })}{' '}
                <span className="text-lg font-bold text-white">گرم</span>
              </div>
              <div className="flex items-center justify-center gap-3 text-xs text-zinc-300 pt-1 font-mono">
                <span>معادل: {findWeightResult.soot.toLocaleString('fa-IR')} سوت</span>
                <span>·</span>
                <span>معادل: {findWeightResult.mesghal.toLocaleString('fa-IR')} مثقال</span>
              </div>
            </div>

            {/* Breakdown */}
            <div className="space-y-1.5 text-xs text-zinc-300 border-t border-zinc-800 pt-3">
              <div className="flex justify-between">
                <span>ارزش طلای خام:</span>
                <span className="font-mono text-white font-bold">{formatToman(findWeightResult.rawGold)} ت</span>
              </div>
              <div className="flex justify-between">
                <span>مبلغ اجرت ساخت ({wFeePercent}٪):</span>
                <span className="font-mono text-amber-300 font-bold">{formatToman(findWeightResult.fee)} ت</span>
              </div>
              <div className="flex justify-between">
                <span>سود فروشگاه ({wProfitPercent}٪):</span>
                <span className="font-mono text-zinc-200 font-bold">{formatToman(findWeightResult.profit)} ت</span>
              </div>
              {wTaxActive && (
                <div className="flex justify-between">
                  <span>مالیات ارزش افزوده:</span>
                  <span className="font-mono text-zinc-300 font-bold">{formatToman(findWeightResult.tax)} ت</span>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                const text = `محاسبه معکوس وزن طلا:\n` +
                  `مبلغ کل: ${formatToman(wTotalAmount)} تومان\n` +
                  `وزن دقیق: ${findWeightResult.weight} گرم (${findWeightResult.soot} سوت)\n` +
                  `نرخ طلا: ${formatToman(wGoldRate)} تومان\n` +
                  `اجرت: ${wFeePercent}٪ | سود: ${wProfitPercent}٪`;
                handleCopyText(text);
              }}
              className="w-full h-11 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
            >
              <Copy className="w-4 h-4 text-[#d4af37]" />
              <span>کپی مشخصات وزن</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. TAB: FIND FEE & PROFIT (پیدا کردن سود و اجرت) */}
      {/* ========================================================================= */}
      {activeSubTab === 'find-fee' && (
        <div className="space-y-4">
          <div className="bg-zinc-900/80 p-4 sm:p-5 rounded-3xl border border-zinc-800 space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <Percent className="w-4 h-4 text-[#ffd700]" />
                <h3 className="text-sm font-black text-white">پیدا کردن درصد سود و اجرت فاکتور</h3>
              </div>
              <span className="text-[11px] text-zinc-400">تفکیک اجرت ساخت و سود</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              {/* Total Final Price */}
              <div className="sm:col-span-2 bg-zinc-950 p-3.5 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">مبلغ نهایی پرداختی (تومان)</label>
                  <span className="font-mono text-[#ffd700] font-bold">{formatToman(fTotalAmount)} تومان</span>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(fTotalAmount)}
                  onChange={(e) => setFTotalAmount(parseNumber(e.target.value))}
                  placeholder="مبلغ نهایی..."
                  className="w-full h-12 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-lg font-black text-[#ffd700] font-mono focus:border-[#d4af37] outline-none"
                />
              </div>

              {/* Weight */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <label className="text-xs font-bold text-zinc-300 block">وزن طلا (گرم)</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.001"
                    value={fWeight || ''}
                    onChange={(e) => setFWeight(parseFloatNumber(e.target.value))}
                    placeholder="مثال: ۶.۵"
                    className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                  />
                  <span className="absolute left-3 top-3 text-[11px] text-zinc-400">گرم</span>
                </div>
              </div>

              {/* Gold Rate */}
              <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-zinc-300">نرخ هر گرم طلای ۱۸ عیار</label>
                  <button
                    type="button"
                    onClick={() => setFGoldRate(goldPrice)}
                    className="text-[10px] text-[#d4af37]"
                  >
                    تابلو
                  </button>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={formatToman(fGoldRate)}
                  onChange={(e) => setFGoldRate(parseNumber(e.target.value))}
                  className="w-full h-11 px-3 bg-zinc-900 border border-zinc-700 rounded-xl text-sm font-bold text-white font-mono focus:border-[#d4af37] outline-none"
                />
              </div>

              {/* Tax Included Toggle */}
              <div className="sm:col-span-2 bg-zinc-950 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">مالیات بر ارزش‌افزوده در این فاکتور</span>
                  <span className="text-[10px] text-zinc-400">آیا ۹٪ ارزش‌افزوده روی سود و اجرت حساب شده است؟</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFTaxActive(!fTaxActive)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    fTaxActive
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {fTaxActive ? 'بله، لحاظ شده (۹٪)' : 'خیر، بدون مالیات'}
                </button>
              </div>

            </div>

          </div>

          {/* RESULT CARD FOR FIND FEE & PROFIT */}
          <div className="bg-gradient-to-br from-zinc-900 via-zinc-950 to-black p-5 rounded-3xl border-2 border-[#d4af37]/60 shadow-2xl relative overflow-hidden space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#ffd700]" />
                <span>تفکیک سود و اجرت کشف‌شده</span>
              </span>
              <span className="text-[11px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-full font-mono">
                سود قانونی ۷٪
              </span>
            </div>

            {/* Split cards for Wage & Profit */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              <div className="bg-[#d4af37]/15 p-4 rounded-2xl border border-[#d4af37]/40 text-center space-y-1">
                <span className="text-xs font-bold text-amber-200">درصد اجرت ساخت:</span>
                <div className="text-2xl sm:text-3xl font-black text-[#ffd700] font-mono">
                  {findFeeResult.feePercent.toLocaleString('fa-IR')}٪
                </div>
                <div className="text-[11px] text-zinc-300 font-mono">
                  مبلغ اجرت: {formatToman(findFeeResult.feeAmount)} ت
                </div>
              </div>

              <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 text-center space-y-1">
                <span className="text-xs font-bold text-zinc-300">سود طلافروشی (قانونی):</span>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                  ۷٪
                </div>
                <div className="text-[11px] text-zinc-400 font-mono">
                  مبلغ سود: {formatToman(findFeeResult.profitAmount)} ت
                </div>
              </div>

            </div>

            {/* Summary details */}
            <div className="bg-zinc-950 p-3.5 rounded-2xl border border-zinc-800 space-y-2 text-xs">
              <div className="flex justify-between text-zinc-300">
                <span>مجموع درصد سود و اجرت:</span>
                <span className="font-mono text-[#ffd700] font-bold">
                  {findFeeResult.totalMarkupPercent.toLocaleString('fa-IR')}٪
                </span>
              </div>
              <div className="flex justify-between text-zinc-300">
                <span>ارزش طلای خام:</span>
                <span className="font-mono text-white font-bold">{formatToman(findFeeResult.rawGold)} تومان</span>
              </div>
              <div className="flex justify-between text-zinc-300">
                <span>کل مبلغ مازاد (سود + اجرت):</span>
                <span className="font-mono text-zinc-200 font-bold">{formatToman(findFeeResult.totalMarkup)} تومان</span>
              </div>
              {fTaxActive && (
                <div className="flex justify-between text-zinc-300">
                  <span>مالیات ارزش‌افزوده پرداخت‌شده:</span>
                  <span className="font-mono text-zinc-300 font-bold">{formatToman(findFeeResult.taxAmount)} تومان</span>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                const text = `کشف سود و اجرت فاکتور:\n` +
                  `مبلغ پرداختی: ${formatToman(fTotalAmount)} تومان\n` +
                  `وزن: ${fWeight} گرم | نرخ طلا: ${formatToman(fGoldRate)} ت\n` +
                  `درصد اجرت ساخت: ${findFeeResult.feePercent}٪ (${formatToman(findFeeResult.feeAmount)} ت)\n` +
                  `سود طلافروش: ۷٪ (${formatToman(findFeeResult.profitAmount)} ت)\n` +
                  `مجموع سود و اجرت: ${findFeeResult.totalMarkupPercent}٪`;
                handleCopyText(text);
              }}
              className="w-full h-11 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
            >
              <Copy className="w-4 h-4 text-[#d4af37]" />
              <span>کپی نتیجه سود و اجرت</span>
            </button>

          </div>
        </div>
      )}

    </div>
  );
};
